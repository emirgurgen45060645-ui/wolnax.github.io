function anasayfa(){
    window.location.href = "kullanici.html";
}

function modalAc() {
    document.getElementById("modal").style.display = "flex";
    }

      document.getElementById("hayirBtn").addEventListener("click", function() {
      document.getElementById("modal").style.display = "none";
    });

   document.getElementById("evetBtn").addEventListener("click", function() {

    const kullanici = document.getElementById("silkullanici").value.trim();
    const sifre = document.getElementById("silsifre").value.trim();

    const kayitliSifre = localStorage.getItem(kullanici);

    if (kayitliSifre && sifre === kayitliSifre) {

        // Hesabı sil
        localStorage.removeItem(kullanici);

        document.getElementById("modal").style.display = "none";
        document.getElementById("successOverlay").style.display = "flex";

        setTimeout(() => {
            window.location.href = "index.html";
        }, 2000);

    } else {
        alert("Kullanıcı adı veya şifre yanlış!");
    }

});